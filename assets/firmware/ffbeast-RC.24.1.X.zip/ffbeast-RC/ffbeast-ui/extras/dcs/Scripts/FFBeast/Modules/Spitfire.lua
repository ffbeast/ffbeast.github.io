-- Structure: [draw_argument_id_of_damage_animation] = damage_multiplier
-- use damage_multiplier to make effect of specific damage stronger or weaker
-- KEEP LIST OF DAMAGE VARS AS SHORT AS POSSIBLE!
local damageVars = {
    [147] = 1,
    [148] = 1,
    [149] = 1,
    [150] = 1,
    [157] = 1,
    [158] = 1,
    [213] = 1,
    [214] = 1,
    [215] = 1,
    [223] = 1,
    [224] = 1,
    [225] = 1,
    [233] = 1,
    [234] = 1,
    [235] = 1,
    [236] = 1,
    [242] = 1
}

-- main guns
local function getGunTrigger0(trigger)
    if (trigger == 30) or (trigger == 50) then
        return  1
    else
        return 0
    end
end

-- small guns
local function getGunTrigger1(trigger)
    if (trigger == 10) or (trigger == 50) then
        return  1
    else
        return 0
    end
end

local function getAbsEngineRPM(percent)
    return FFBeast.round(percent * 3000 / 100)
end

local _api = {}

function _api.getCommonData(mainPanel)
    local result = FFBeast.getCommonData()
    local trigger = FFBeast.round(mainPanel:get_argument_value(7) * 100)
    result.eng_rpm_abs = getAbsEngineRPM(result.eng_rpm_norm)
    result.gun_trg0 = getGunTrigger0(trigger) -- Hispano HS.404
    result.gun_trg1 = getGunTrigger1(trigger) -- Browning М1919
    result.dmg = FFBeast.getDamage(damageVars)
    result.name = "Spitfire"
    return result
end

FFBeast.modules["SpitfireLFMkIX"] = _api
FFBeast.modules["SpitfireLFMkIXCW"] = _api