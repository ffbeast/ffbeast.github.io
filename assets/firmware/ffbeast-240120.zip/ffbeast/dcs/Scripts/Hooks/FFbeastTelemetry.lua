do
	package.path  = package.path..";"..lfs.currentdir().."/LuaSocket/?.lua"
	package.cpath = package.cpath..";"..lfs.currentdir().."/LuaSocket/?.dll"
	socket = require("socket")
	host = host or "localhost"
	port = port or 29778
	FFB_socket = socket.try(socket.udp())
	FFB_socket:settimeout(100)
	FFB_socket:setpeername(host,port)


	local ffbeastCallbacks = {}

	function ffbeastCallbacks.onSimulationStop()
		socket.try(FFB_socket:send(string.format("%s;%.2f;%.2f;%.2f;%.2f;%.2f;%.2f;%.2f;%.2f;%s\n", 0,0,0,0,0,0,0,0,0,0)))
	end

  local lTime = DCS.getModelTime()
  
	function ffbeastCallbacks.onSimulationFrame()

		local slot_airspeed = 0.0
		local slot_vertical_speed = 0.0
		local slot_aoa = 0.0
		local slot_g_force = 0.0
		local slot_gear = 0.0
		local slot_airbrake = 0.0
		local slot_flaps = 0.0
		local slot_thrust = 0.0
		local slot_on_ground = 0.0
		
		local self = Export.LoGetSelfData()
		
		if (self ~= nil) then
		slot_airspeed = Export.LoGetIndicatedAirSpeed()*3.6
		slot_vertical_speed = Export.LoGetVerticalVelocity()
		slot_aoa = Export.LoGetAngleOfAttack()
		slot_g_force = Export.LoGetAccelerationUnits().y
		slot_gear = Export.LoGetMechInfo().gear.value
		slot_airbrake = Export.LoGetMechInfo().speedbrakes.value
		slot_flaps = Export.LoGetMechInfo().flaps.value
		slot_thrust = (Export.LoGetEngineInfo().RPM.left + Export.LoGetEngineInfo().RPM.right)
		
		local generic_string = string.format("%.2f-%.2f-%.2f", Export.LoGetMechInfo().flaps.value,Export.LoGetAircraftDrawArgumentValue(9), Export.LoGetAircraftDrawArgumentValue(10))
		
		--Weight On Wheels?
		LeftGear =  Export.LoGetAircraftDrawArgumentValue(6)
		NoseGear =  Export.LoGetAircraftDrawArgumentValue(1)
		RightGear =  Export.LoGetAircraftDrawArgumentValue(4)
	   
		--OnGround status is determined by the compression of ANY gear strut
		if (LeftGear > 0 or NoseGear > 0 or RightGear > 0)
			then
				slot_on_ground = 1
			else
				slot_on_ground = 0
		end

		
		socket.try(FFB_socket:send(string.format("%s;%.2f;%.2f;%.2f;%.2f;%.2f;%.2f;%.2f;%.2f;%s\n",
													self.Name,
													slot_airspeed,
													slot_vertical_speed,
													slot_aoa,
													slot_g_force,
													slot_gear,
													slot_airbrake,
													slot_flaps,
													slot_thrust,
													slot_on_ground
													)))	
		end
	end
    

	DCS.setUserCallbacks(ffbeastCallbacks)

end
