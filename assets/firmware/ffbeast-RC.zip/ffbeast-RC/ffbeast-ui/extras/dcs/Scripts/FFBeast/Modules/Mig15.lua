-- Structure: [draw_argument_id_of_damage_animation] = damage_multiplier
-- use damage_multiplier to make effect of specific damage stronger or weaker
-- KEEP LIST OF DAMAGE VARS AS SHORT AS POSSIBLE!
local damageVars = {
    [146] = 1,
    [149] = 1,
    [150] = 1,
    [152] = 1,
    [153] = 1,
    [154] = 1,
    [156] = 1,
    [157] = 1,
    [158] = 1,
    [213] = 1,
    [214] = 1,
    [215] = 1,
    [223] = 1,
    [224] = 1,
    [225] = 1,
    [234] = 1,
    [236] = 1,
    [241] = 1,
    [242] = 1,
}

local function getGunTrigger(trigger)
    if (trigger == 100) then
        return  1
    else
        return 0
    end
end

local _api = {}

function _api.getCommonData(mainPanel)
    local result = FFBeast.getCommonData()
    local trigger1 = FFBeast.round(mainPanel:get_argument_value(193) * 100)
    local trigger2 = FFBeast.round(mainPanel:get_argument_value(194) * 100)
    result.gun_trg0 = getGunTrigger(trigger1) -- N-37
    result.gun_trg1 = getGunTrigger(trigger2) -- NR-23
    result.dmg = FFBeast.getDamage(damageVars)
    result.name = "MiG-15"
    return result
end

FFBeast.modules["MiG-15bis"] = _api
--TODO: add mapping to name reported by FC