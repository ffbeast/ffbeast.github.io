-- Structure: [draw_argument_id_of_damage_animation] = damage_multiplier
-- use damage_multiplier to make effect of specific damage stronger or weaker
-- KEEP LIST OF DAMAGE VARS AS SHORT AS POSSIBLE!
local damageVars = {
    [146] = 1,
    [147] = 1,
    [148] = 1,
    [149] = 1,
    [150] = 1,
    [152] = 1,
    [156] = 1,
    [157] = 1,
    [158] = 1,
    [159] = 1,
    [161] = 1,
    [167] = 1,
    [213] = 1,
    [214] = 1,
    [223] = 1,
    [224] = 1,
    [233] = 1,
    [235] = 1,
    [247] = 1
}

local function getGunTrigger0(trigger, tempo)
    if (tempo == 0) and (trigger > 0) then
        return 1
    else
        return 0
    end
end

local function getGunTrigger1(trigger, tempo)
    if (tempo == 100) and (trigger > 0) then
        return 1
    else
        return 0
    end
end

local function getGunTrigger2(trigger)
    if (trigger > 0) then
        return 1
    else
        return 0
    end
end

local _api = {}

function _api.getCommonData(mainPanel)
    local result = FFBeast.getCommonData()
    local trigger1 = FFBeast.round(mainPanel:get_argument_value(615) * 100)
    local trigger2 = FFBeast.round(mainPanel:get_argument_value(614) * 100) --TODO: replace with correct trigger value
    local tempo = FFBeast.round(mainPanel:get_argument_value(398) * 100)
    result.gun_trg0 = getGunTrigger0(trigger1, tempo) -- high tempo
    result.gun_trg1 = getGunTrigger1(trigger1, tempo) -- low tempo
    result.gun_trg2 = getGunTrigger2(trigger2) -- GSh pod
    result.dmg = FFBeast.getDamage(damageVars)
    result.name = "Ka-50"
    return result
end

FFBeast.modules["Ka-50"] = _api
FFBeast.modules["Ka-50_3"] = _api
