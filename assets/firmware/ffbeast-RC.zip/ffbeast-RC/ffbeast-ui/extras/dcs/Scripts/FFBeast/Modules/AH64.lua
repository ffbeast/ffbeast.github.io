-- Structure: [draw_argument_id_of_damage_animation] = damage_multiplier
-- use damage_multiplier to make effect of specific damage stronger or weaker
-- KEEP LIST OF DAMAGE VARS AS SHORT AS POSSIBLE!
local damageVars = {

}

local _api = {}

function _api.getCommonData(mainPanel)
    local result = FFBeast.getCommonData()
    result.dmg = FFBeast.getDamage(damageVars)
    result.name = "AH-64"
    return result
end

FFBeast.modules["AH-64D_BLK_II"] = _api