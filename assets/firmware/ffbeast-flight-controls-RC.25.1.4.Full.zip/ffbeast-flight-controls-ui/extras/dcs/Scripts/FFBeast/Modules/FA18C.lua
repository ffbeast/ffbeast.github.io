-- Structure: [draw_argument_id_of_damage_animation] = damage_multiplier
-- use damage_multiplier to make effect of specific damage stronger or weaker
-- KEEP LIST OF DAMAGE VARS AS SHORT AS POSSIBLE!
local damageVars = {
    [146] = 1,
    [148] = 1,
    [149] = 1,
    [150] = 1,
    [152] = 1,
    [153] = 1,
    [154] = 1,
    [156] = 1,
    [157] = 1,
    [158] = 1,
    [213] = 1,
    [214] = 1,
    [215] = 1,
    [223] = 1,
    [224] = 1,
    [225] = 1,
    [233] = 1,
    [235] = 1,
    [242] = 1,
    [245] = 1,
    [297] = 1,
    [298] = 1,
    [299] = 1
}

local _api = {}

function _api.getCommonData(mainPanel)
    local result = FFBeast.getCommonData()
    result.ab = FFBeast.round(FFBeast.max(LoGetAircraftDrawArgumentValue(28), LoGetAircraftDrawArgumentValue(29)) * 100)
    result.dmg = FFBeast.getDamage(damageVars)
    result.name = "FA-18C"
    return result
end

FFBeast.modules["FA-18C_hornet"] = _api