-- Structure: [draw_argument_id_of_damage_animation] = damage_multiplier
-- use damage_multiplier to make effect of specific damage stronger or weaker
-- KEEP LIST OF DAMAGE VARS AS SHORT AS POSSIBLE!
local damageVars = {
    -- TODO: set damageVars
}

local function getGunTrigger(trigger)
    if (trigger > 0) then
        return 1
    else
        return 0
    end
end

local function getAbsEngineRPM(percent)
    return FFBeast.round(percent * 2700 / 100)
end

local _api = {}

function _api.getCommonData(mainPanel)
    local result = FFBeast.getCommonData()
    local trigger1 = FFBeast.round(mainPanel:get_argument_value(REPLACEME) * 100) -- TODO: set correct trigger
    result.eng_rpm_abs = getAbsEngineRPM(result.eng_rpm_norm)
    result.gun_trg0 = getGunTrigger(trigger1) -- Machine Gun
    result.dmg = FFBeast.getDamage(damageVars)
    result.name = "P-47D"

    return result
end

FFBeast.modules["P-47D-30"] = _api
FFBeast.modules["P-47D-30bl1"] = _api
FFBeast.modules["P-47D-40"] = _api

