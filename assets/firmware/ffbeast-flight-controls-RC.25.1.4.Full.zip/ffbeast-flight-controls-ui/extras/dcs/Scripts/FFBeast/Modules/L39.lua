-- Structure: [draw_argument_id_of_damage_animation] = damage_multiplier
-- use damage_multiplier to make effect of specific damage stronger or weaker
-- KEEP LIST OF DAMAGE VARS AS SHORT AS POSSIBLE!
local damageVars = {
    [148] = 1,
    [149] = 1,
    [150] = 1,
    [152] = 1,
    [153] = 1,
    [154] = 1,
    [156] = 1,
    [157] = 1,
    [158] = 1,
    [213] = 1,
    [214] = 1,
    [215] = 1,
    [216] = 1,
    [217] = 1,
    [223] = 1,
    [224] = 1,
    [225] = 1,
    [226] = 1,
    [227] = 1,
    [233] = 1,
    [234] = 1,
    [235] = 1,
    [236] = 1,
    [238] = 1,
    [240] = 1,
    [241] = 1,
    [242] = 1,
    [247] = 1,
}

local _api = {}

function _api.getCommonData(mainPanel)
    local result = FFBeast.getCommonData()
    result.dmg = FFBeast.getDamage(damageVars)
    result.name = "L-39"
    return result
end

FFBeast.modules["L-39C"] = _api
FFBeast.modules["L-39ZA"] = _api
