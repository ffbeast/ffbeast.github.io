-- Structure: [draw_argument_id_of_damage_animation] = damage_multiplier
-- use damage_multiplier to make effect of specific damage stronger or weaker
-- KEEP LIST OF DAMAGE VARS AS SHORT AS POSSIBLE!
local damageVars = {

}

local _api = {}

function _api.getCommonData(mainPanel)
    local result = FFBeast.getCommonData()
    result.dmg = FFBeast.getDamage(damageVars)
    result.name = "override_module_name_here"
    return result
end

FFBeast.modules["name_of_module_here"] = _api;