-- Structure: [draw_argument_id_of_damage_animation] = damage_multiplier
-- use damage_multiplier to make effect of specific damage stronger or weaker
-- KEEP LIST OF DAMAGE VARS AS SHORT AS POSSIBLE!
local damageVars = {
    [151] = 1,
    [152] = 1,
    [153] = 1,
    [154] = 1,
    [157] = 1,
    [158] = 1,
    [213] = 1,
    [214] = 1,
    [215] = 1,
    [216] = 1,
    [217] = 1,
    [223] = 1,
    [224] = 1,
    [225] = 1,
    [226] = 1,
    [227] = 1,
    [233] = 1,
    [234] = 1,
    [235] = 1,
    [236] = 1,
    [237] = 1,
    [239] = 1,
    [243] = 1,
    [247] = 1
}

local function getGunTrigger(trigger)
    if (trigger == 100) then
        return 1
    else
        return 0
    end
end

local function getAbsEngineRPM(percent)
    return FFBeast.round(percent * 2700 / 100)
end

local _api = {}

function _api.getCommonData(mainPanel)
    local result = FFBeast.getCommonData()
    local trigger1 = FFBeast.round(mainPanel:get_argument_value(13) * 100)
    local trigger2 = FFBeast.round(mainPanel:get_argument_value(9) * 100)
    result.eng_rpm_abs = getAbsEngineRPM(result.eng_rpm_norm)
    result.gun_trg0 = getGunTrigger(trigger1) -- Center MG 151 + MG 131
    result.gun_trg1 = getGunTrigger(trigger2) -- Outer MG 151
    result.dmg = FFBeast.getDamage(damageVars)
    return result
end

FFBeast.modules["FW-190A8"] = _api
