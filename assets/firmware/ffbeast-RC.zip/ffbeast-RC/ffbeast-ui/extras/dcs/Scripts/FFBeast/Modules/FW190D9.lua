-- Structure: [draw_argument_id_of_damage_animation] = damage_multiplier
-- use damage_multiplier to make effect of specific damage stronger or weaker
-- KEEP LIST OF DAMAGE VARS AS SHORT AS POSSIBLE!
local damageVars = {
    -- TODO: set damageVars
}

local function getGunTrigger(trigger)
    if (trigger == 100) then
        return 1
    else
        return 0
    end
end

local function getAbsEngineRPM(percent)
    return FFBeast.round(percent * 2700 / 100) -- TODO: set correct RPM
end

local _api = {}

function _api.getCommonData(mainPanel)
    local result = FFBeast.getCommonData()
    local trigger1 = FFBeast.round(mainPanel:get_argument_value(13) * 100) -- TODO: set correct trigger
    local trigger2 = FFBeast.round(mainPanel:get_argument_value(9) * 100) -- TODO: set correct trigger
    result.eng_rpm_abs = getAbsEngineRPM(result.eng_rpm_norm)
    result.gun_trg0 = getGunTrigger(trigger1) -- Center MG 151 + MG 131
    result.gun_trg1 = getGunTrigger(trigger2) -- Outer MG 151
    result.dmg = FFBeast.getDamage(damageVars)
    return result
end

FFBeast.modules["FW-190D9"] = _api -- TODO: check if can be combined with 190A8
