-- Structure: [draw_argument_id_of_damage_animation] = damage_multiplier
-- use damage_multiplier to make effect of specific damage stronger or weaker
-- KEEP LIST OF DAMAGE VARS AS SHORT AS POSSIBLE!
local damageVars = {
    [81] = 1,
    [149] = 1,
    [150] = 1,
    [153] = 1,
    [154] = 1,
    [161] = 1,
    [162] = 1,
    [163] = 1,
    [167] = 1,
    [168] = 1,
    [169] = 1,
    [213] = 1,
    [214] = 1,
    [215] = 1,
    [223] = 1,
    [224] = 1,
    [225] = 1,
    [233] = 1,
    [235] = 1,
    [242] = 1,
    [243] = 1,
}

local _api = {}

function _api.getCommonData(mainPanel)
    local result = FFBeast.getCommonData()
    result.dmg = FFBeast.getDamage(damageVars)
    return result
end

FFBeast.modules["Su-25T"] = _api