-- Structure: [draw_argument_id_of_damage_animation] = damage_multiplier
-- use damage_multiplier to make effect of specific damage stronger or weaker
-- KEEP LIST OF DAMAGE VARS AS SHORT AS POSSIBLE!
local damageVars = {

}

local _api = {}

function _api.getCommonData(mainPanel)
    local result = FFBeast.getCommonData()
    result.dmg = FFBeast.getDamage(damageVars)
    result.name = "SA342"
    return result
end

FFBeast.modules["SA342L"] = _api
FFBeast.modules["SA342M"] = _api
FFBeast.modules["SA342Minigun"] = _api
