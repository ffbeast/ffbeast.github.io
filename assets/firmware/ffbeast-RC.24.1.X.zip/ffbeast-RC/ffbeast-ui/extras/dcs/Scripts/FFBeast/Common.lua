package.path = package.path .. ";.\\LuaSocket\\?.lua;Scripts\\?.lua;"
package.cpath = package.cpath .. ";.\\LuaSocket\\?.dll"
local JSON = loadfile("Scripts\\JSON.lua")()
local lfs = require('lfs')

function FFBeast.round(num, numDecimalPlaces)
    local value = num or 0
    local multiplier = 10 ^ (numDecimalPlaces or 0)
    return math.floor(value * multiplier + 0.5) / multiplier
end

function FFBeast.max(a, b)
    if a > b then
        return a
    else
        return b
    end
end

function FFBeast.getDamage(draw_vars)
    if FFBeast.exportDamage then
        local sum = 0
        for key, var in ipairs(draw_vars) do
            local value = LoGetAircraftDrawArgumentValue(var)
            sum = sum + value * key
        end
        return FFBeast.round(sum * 100)
    else
        return 0
    end
end

function FFBeast.getCommonData()

    local engine = LoGetEngineInfo()
    local mech = LoGetMechInfo()
    local payload = LoGetPayloadInfo()
    local snares = LoGetSnares()
    local result = {}

    result.speed = FFBeast.round(LoGetIndicatedAirSpeed() * 3.6, 2)
    result.v_speed = FFBeast.round(LoGetVerticalVelocity(), 2)
    result.aoa = FFBeast.round(LoGetAngleOfAttack(), 2)
    result.g = FFBeast.round(LoGetAccelerationUnits().y, 2)
    result.eng_rpm_norm = FFBeast.round(FFBeast.max(engine.RPM.left, engine.RPM.right))
    result.rotor_rpm_abs = FFBeast.round(get_param_handle("BASE_SENSOR_PROPELLER_RPM"):get())
    result.gear = FFBeast.round(mech.gear.value * 100)
    result.flaps = FFBeast.round(mech.flaps.value * 100)
    result.sp_br = FFBeast.round(mech.speedbrakes.value * 100)
    result.wow = FFBeast.round((LoGetAircraftDrawArgumentValue(6) + LoGetAircraftDrawArgumentValue(1) + LoGetAircraftDrawArgumentValue(4)) * 100)
    result.shk_amp = FFBeast.round(LoGetShakeAmplitude() * 100)
    result.shells = payload.Cannon.shells;
    result.snares = snares.chaff + snares.flare
    result.pld = {}
    for key, value in pairs(payload.Stations) do
        if value.weapon.level1 > 0 then
            local w = {}
            w.count = value.count
            w.id = string.format("%d.%d.%d.%d", value.weapon.level1, value.weapon.level2, value.weapon.level3, value.weapon.level4)
            table.insert(result.pld, w)
        end
    end

    return result

end

function FFBeast.dumpNewWeaponsShort()
    FFBeast.weapons_file = io.open(lfs.writedir() .. "/Logs/weapons.json", "r")
    local weapons_file_content = FFBeast.weapons_file:read("*a")
    local existingWeapons = JSON:decode(weapons_file_content)
    FFBeast.weapons_file:close()
    FFBeast.weapons_file = io.open(lfs.writedir() .. "/Logs/weapons.json", "w")
    local payload = LoGetPayloadInfo()
    for key, value in pairs(payload.Stations) do
        local item = {}
        local id = string.format("%d.%d.%d.%d", value.weapon.level1, value.weapon.level2, value.weapon.level3, value.weapon.level4)
        item.name = LoGetNameByType(value.weapon.level1, value.weapon.level2, value.weapon.level3, value.weapon.level4);
        item.weight = 100
        if (item.name:find("UNKNOWN") ~= nil) then
        else
            existingWeapons[id] = item;
        end
    end
    FFBeast.weapons_file:write(JSON:encode(existingWeapons))
    FFBeast.weapons_file:close()
end

function FFBeast.dumpPayloadFull()
    FFBeast.payload_file = io.open(lfs.writedir() .. "/Logs/payload_full.json", "w")
    local payload = LoGetPayloadInfo()
    local result = {}
    for key, value in pairs(payload.Stations) do
        if value.weapon.level1 > 0 then
            local w = {}
            w.count = value.count
            w.id = string.format("%d.%d.%d.%d", value.weapon.level1, value.weapon.level2, value.weapon.level3, value.weapon.level4)
            w.name = LoGetNameByType(value.weapon.level1, value.weapon.level2, value.weapon.level3, value.weapon.level4);
            table.insert(result, w)
        end
    end
    FFBeast.payload_file:write(JSON:encode(result))
    FFBeast.payload_file:close()
end


