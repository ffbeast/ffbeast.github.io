package.path = package.path .. ";.\\LuaSocket\\?.lua;Scripts\\?.lua;"
package.cpath = package.cpath .. ";.\\LuaSocket\\?.dll"
local JSON = loadfile("Scripts\\JSON.lua")()
local lfs = require('lfs')
local socket = require("socket")

FFBeast = {}
FFBeast.exportDamage = true

FFBeast.modules = {}

dofile(lfs.writedir() .. [[Scripts\FFBeast\Port.lua]])
dofile(lfs.writedir() .. [[Scripts\FFBeast\Common.lua]])

-- KEEP ALPHABETICAL ORDER!
dofile(lfs.writedir() .. [[Scripts\FFBeast\Modules\A10.lua]])
dofile(lfs.writedir() .. [[Scripts\FFBeast\Modules\AH64.lua]])
dofile(lfs.writedir() .. [[Scripts\FFBeast\Modules\BF109.lua]])
dofile(lfs.writedir() .. [[Scripts\FFBeast\Modules\F5E.lua]])
dofile(lfs.writedir() .. [[Scripts\FFBeast\Modules\F14.lua]])
dofile(lfs.writedir() .. [[Scripts\FFBeast\Modules\F15C.lua]])
dofile(lfs.writedir() .. [[Scripts\FFBeast\Modules\F16C.lua]])
dofile(lfs.writedir() .. [[Scripts\FFBeast\Modules\FA18C.lua]])
dofile(lfs.writedir() .. [[Scripts\FFBeast\Modules\FW190A8.lua]])
dofile(lfs.writedir() .. [[Scripts\FFBeast\Modules\FW190D9.lua]])
dofile(lfs.writedir() .. [[Scripts\FFBeast\Modules\Ka50.lua]])
dofile(lfs.writedir() .. [[Scripts\FFBeast\Modules\L39.lua]])
dofile(lfs.writedir() .. [[Scripts\FFBeast\Modules\Mi24.lua]])
dofile(lfs.writedir() .. [[Scripts\FFBeast\Modules\Mi8.lua]])
dofile(lfs.writedir() .. [[Scripts\FFBeast\Modules\Mig15.lua]])
dofile(lfs.writedir() .. [[Scripts\FFBeast\Modules\Mig29.lua]])
dofile(lfs.writedir() .. [[Scripts\FFBeast\Modules\P47D.lua]])
dofile(lfs.writedir() .. [[Scripts\FFBeast\Modules\P51D.lua]])
dofile(lfs.writedir() .. [[Scripts\FFBeast\Modules\SA342.lua]])
dofile(lfs.writedir() .. [[Scripts\FFBeast\Modules\Spitfire.lua]])
dofile(lfs.writedir() .. [[Scripts\FFBeast\Modules\Su25.lua]])
dofile(lfs.writedir() .. [[Scripts\FFBeast\Modules\Su25T.lua]])
dofile(lfs.writedir() .. [[Scripts\FFBeast\Modules\Su27.lua]])
dofile(lfs.writedir() .. [[Scripts\FFBeast\Modules\Su33.lua]])

FFBeast.socket = socket.try(socket.udp())
FFBeast.socket:settimeout(100)
FFBeast.socket:setpeername("localhost", FFBeast.port)

FFBeast.Start = function(self)
    --FFBeast.dumpNewWeaponsShort()
    --FFBeast.dumpPayloadFull()
    --show_param_handles_list()
end

FFBeast.Stop = function(self)
    if socket and FFBeast.socket then
        local result = {}
        result.type = "end";
        socket.try(FFBeast.socket:send(JSON:encode(result)))
    end
end

FFBeast.Frame = function(self)
    if socket and FFBeast.socket then
        local self = LoGetSelfData()
        if (self ~= nil) then
            local result = nil
            local module = FFBeast.modules[self.Name];
            if (module ~= nil) then
                result = module.getCommonData(GetDevice(0));
            else
                result = FFBeast.getCommonData();
            end
            if (result.name == nil) then
                result.name = self.Name
            end
            socket.try(FFBeast.socket:send(JSON:encode(result)))
        end
    end
end

do
    local _luaExportStart = LuaExportStart
    LuaExportStart = function()
        FFBeast:Start()
        if _luaExportStart then
            _luaExportStart()
        end
    end
end

-- Works after every simulation frame
do
    local _luaExportAfterNextFrame = LuaExportAfterNextFrame
    LuaExportAfterNextFrame = function()
        FFBeast:Frame()
        if _luaExportAfterNextFrame then
            _luaExportAfterNextFrame()
        end
    end
end

-- Works after mission stop
do
    local _luaExportStop = LuaExportStop
    LuaExportStop = function()
        FFBeast:Stop()
        if _luaExportStop then
            _luaExportStop()
        end
    end
end