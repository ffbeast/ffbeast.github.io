-- Structure: [draw_argument_id_of_damage_animation] = damage_multiplier
-- use damage_multiplier to make effect of specific damage stronger or weaker
-- KEEP LIST OF DAMAGE VARS AS SHORT AS POSSIBLE!
local damageVars = {
    [61] = 1,
    [62] = 1,
    [81] = 1,
    [148] = 1,
    [149] = 1,
    [150] = 1,
    [153] = 1,
    [154] = 1,
    [156] = 1,
    [157] = 1,
    [158] = 1,
    [160] = 1,
    [161] = 1,
    [166] = 1,
    [167] = 1,
    [185] = 1,
    [213] = 1,
    [215] = 1,
    [223] = 1,
    [225] = 1,
    [242] = 1,
    [243] = 1,
    [245] = 1,
    [246] = 1,
    [296] = 1,
    [297] = 1,
    [298] = 1,
    [299] = 1,
    [300] = 1,
    [301] = 1
}

local function getGunTrigger0(weaponSelector, trigger, tempo)
    if (weaponSelector == 50) and (tempo == 100) and (trigger > 0) then
        return 1
    else
        return 0
    end
end

local function getGunTrigger1(weaponSelector, trigger, tempo)
    if (weaponSelector == 50) and (tempo == 0) and (trigger > 0) then
        return 1
    else
        return 0
    end
end

local function getGunTrigger2(weaponSelector, trigger)
    if (weaponSelector == 20 or weaponSelector == 30) and (trigger > 0) then
        return 1
    else
        return 0
    end
end

local function getGunTrigger3(weaponSelector, trigger, tempo)
    if (weaponSelector == 20 or weaponSelector == 40)  and (trigger > 0) then
        return 1
    else
        return 0
    end
end

local function getGunTrigger4(weaponSelector, trigger, tempo)
    if (weaponSelector == 10)  and (trigger > 0) then
        return 1
    else
        return 0
    end
end

local _api = {}

function _api.getCommonData(mainPanel)
    local result = FFBeast.getCommonData()
    local tempo = FFBeast.round(mainPanel:get_argument_value(550) * 100)
    local trigger = FFBeast.round(mainPanel:get_argument_value(741) * 100)
    local weaponSelector = FFBeast.round(mainPanel:get_argument_value(523) * 100)
    result.gun_trg0 = getGunTrigger0(weaponSelector, trigger, tempo) -- high tempo
    result.gun_trg1 = getGunTrigger1(weaponSelector, trigger, tempo) -- low tempo
    result.gun_trg2 = getGunTrigger2(weaponSelector, trigger) -- 12.5 pod
    result.gun_trg3 = getGunTrigger3(weaponSelector, trigger) -- 7.65 pod
    result.gun_trg4 = getGunTrigger4(weaponSelector, trigger) -- 30mm grenade launcher
    result.dmg = FFBeast.getDamage(damageVars)
    result.name = "Mi-24"
    return result
end

FFBeast.modules["Mi-24P"] = _api