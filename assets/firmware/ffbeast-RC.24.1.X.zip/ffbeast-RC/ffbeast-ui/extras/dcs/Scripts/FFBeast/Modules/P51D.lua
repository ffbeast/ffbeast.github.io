-- Structure: [draw_argument_id_of_damage_animation] = damage_multiplier
-- use damage_multiplier to make effect of specific damage stronger or weaker
-- KEEP LIST OF DAMAGE VARS AS SHORT AS POSSIBLE!
local damageVars = {
    -- TODO: set damageVars
}

local function getAbsEngineRPM(percent)
    return FFBeast.round(percent * 3000 / 100)
end

local _api = {}

function _api.getCommonData(mainPanel)
    local result = FFBeast.getCommonData()
    result.eng_rpm_abs = getAbsEngineRPM(result.eng_rpm_norm)
    result.dmg = FFBeast.getDamage(damageVars)
    result.name = "P-51D"

    return result
end

FFBeast.modules["TF-51D"] = _api
FFBeast.modules["P-51D"] = _api
FFBeast.modules["P-51D-30-NA"] = _api

