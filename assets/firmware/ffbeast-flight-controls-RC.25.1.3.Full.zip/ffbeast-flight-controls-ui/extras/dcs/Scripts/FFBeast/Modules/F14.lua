-- Structure: [draw_argument_id_of_damage_animation] = damage_multiplier
-- use damage_multiplier to make effect of specific damage stronger or weaker
-- KEEP LIST OF DAMAGE VARS AS SHORT AS POSSIBLE!
local damageVars = {
    [516] = 1,
    [517] = 1,
    [518] = 1,
    [519] = 1,
    [520] = 1,
    [534] = 1,
    [575] = 1,
    [532] = 1,
    [576] = 1,
    [571] = 1,
    [510] = 1,
    [640] = 1,
    [641] = 1
}

local _api = {}

function _api.getCommonData(mainPanel)
    local result = FFBeast.getCommonData()
    result.sp_br = FFBeast.round(LoGetAircraftDrawArgumentValue(400) * 100)
    result.ab = FFBeast.round(FFBeast.max(LoGetAircraftDrawArgumentValue(435), LoGetAircraftDrawArgumentValue(436)) * 100)
    result.dmg = FFBeast.getDamage(damageVars)
    result.name = "F-14"
    return result
end

FFBeast.modules["F-14A-135-GR"] = _api
FFBeast.modules["F-14B"] = _api